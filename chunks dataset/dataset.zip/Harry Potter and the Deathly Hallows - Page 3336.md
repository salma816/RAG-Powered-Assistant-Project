# Harry Potter and the Deathly Hallows

## Page 3336

Xenophilius’s paper-white face appeared over the top of the sideboard. “Obliviate!” cried Hermione, pointing her wand first into his face, then at the floor beneath them. “Deprimo!” She had blasted a hole in the sitting room floor. They fell like boulders, Harry still holding onto her hand for dear life; there was a scream from below, and he glimpsed two men trying to get out of the way as vast quantities of rubble and broken furniture rained all around them from the shattered ceiling. Hermione twisted in midair and the thundering of the collapsing house rang in Harry’s ears as she dragged him once more into darkness.
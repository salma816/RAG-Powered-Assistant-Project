# Harry Potter and the Deathly Hallows

## Page 3162

“I dunno, some Ministry hag.” Mundungus considered for a moment, brow wrinkled. “Little woman. Bow on top of ’er head.” He frowned and then added, “Looked like a toad.” Harry dropped his wand: It hit Mundungus on the nose and shot red sparks into his eyebrows, which ignited. “Aguamenti!” screamed Hermione, and a jet of water streamed from her wand, engulfing a spluttering and choking Mundungus. Harry looked up and saw his own shock reflected in Ron’s and Hermione’s faces. The scars on the back of his right hand seemed to be tingling again.
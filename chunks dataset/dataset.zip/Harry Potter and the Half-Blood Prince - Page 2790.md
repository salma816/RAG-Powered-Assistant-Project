# Harry Potter and the Half-Blood Prince

## Page 2790

“Oh, he definitely wanted the Defense Against the Dark Arts job,” said Dumbledore. “The aftermath of our little meeting proved that. You see, we have never been able to keep a Defense Against the Dark Arts teacher for longer than a year since I refused the post to Lord Voldemort.”
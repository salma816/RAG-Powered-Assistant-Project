# Harry Potter and the Prisoner of Azkaban

## Page 836

where Dumbledore stood waiting with the enormous Quidditch Cup. If only there had been a dementor around. . . . As a sobbing Wood passed Harry the Cup, as he lifted it into the air, Harry felt he could have produced the world’s best Patronus.
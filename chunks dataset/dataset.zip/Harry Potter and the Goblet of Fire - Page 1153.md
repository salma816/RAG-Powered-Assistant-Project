# Harry Potter and the Goblet of Fire

## Page 1153

eyes, which remained cold and shrewd. “How good it is to be here, how good. . . . Viktor, come along, into the warmth . . . you don’t mind, Dumbledore? Viktor has a slight head cold. . . .” Karkaroff beckoned forward one of his students. As the boy passed, Harry caught a glimpse of a prominent curved nose and thick black eyebrows. He didn’t need the punch on the arm Ron gave him, or the hiss in his ear, to recognize that profile. “Harry — it’s Krum!”
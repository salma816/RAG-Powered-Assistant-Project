# Harry Potter and the Order of the Phoenix

## Page 1740

“Cut it out,” he said firmly, rubbing the scar as the pain receded again. “First sign of madness, talking to your own head,” said a sly voice from the empty picture on the wall. Harry ignored it. He felt older than he had ever felt in his life, and it seemed extraordinary to him that barely an hour ago he had been worried about a joke shop and who had gotten a prefect’s badge.
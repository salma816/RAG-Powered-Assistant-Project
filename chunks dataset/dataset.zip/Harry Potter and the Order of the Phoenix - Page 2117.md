# Harry Potter and the Order of the Phoenix

## Page 2117

“Fire away, then, Rita,” said Hermione serenely, fishing a cherry out of the bottom of her glass.
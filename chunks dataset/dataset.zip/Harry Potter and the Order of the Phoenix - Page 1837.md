# Harry Potter and the Order of the Phoenix

## Page 1837

as though he was vaguely tempted by this offer. “Er . . . no, I don’t think I will, thanks,” he said. “Er — not tomorrow. I’ve got loads of homework to do . . .” And he traipsed off to the boys’ stairs, leaving her looking slightly disappointed behind him.
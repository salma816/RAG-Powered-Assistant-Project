# Harry Potter and the Order of the Phoenix

## Page 2289

squad should come with you to look after —” “I am a fully qualified Ministry official, Malfoy, do you really think I cannot manage two wandless teenagers alone?” asked Umbridge sharply. “In any case, it does not sound as though this weapon is something that schoolchildren should see. You will remain here until I return and make sure none of these” — she gestured around at Ron, Ginny, Neville, and Luna — “escape.” “All right,” said Malfoy, looking sulky and disappointed. “And you two can go ahead of me and show me the way,” said Umbridge, pointing at Harry and Hermione with her wand. “Lead on . . .”
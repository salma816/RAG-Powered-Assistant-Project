# Harry Potter and the Sorcerer Stone

## Page 49

one . . . BOOM. The whole shack shivered and Harry sat bolt upright, staring at the door. Someone was outside, knocking to come in.
# Harry Potter and the Order of the Phoenix

## Page 1760

the coach’s dark interior. “You’re not going mad or anything. I can see them too.” “Can you?” said Harry desperately, turning to Luna. He could see the bat- winged horses reflected in her wide, silvery eyes. “Oh yes,” said Luna, “I’ve been able to see them ever since my first day here. They’ve always pulled the carriages. Don’t worry. You’re just as sane as I am.” Smiling faintly, she climbed into the musty interior of the carriage after Ron. Not altogether reassured, Harry followed her.
# Harry Potter and the Order of the Phoenix

## Page 2406

Harry nodded. He somehow could not find words to tell them what it meant to him, to see them all ranged there, on his side. Instead he smiled, raised a hand in farewell, turned around, and led the way out of the station toward the sunlit street, with Uncle Vernon, Aunt Petunia, and Dudley hurrying along in his wake.